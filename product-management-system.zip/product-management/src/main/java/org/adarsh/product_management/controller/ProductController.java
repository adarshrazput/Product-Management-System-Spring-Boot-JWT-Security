package org.adarsh.product_management.controller;

import jakarta.validation.Valid;
import org.adarsh.product_management.dto.request.ProductPatchRequestDTO;
import org.adarsh.product_management.dto.request.ProductRequestDTO;
import org.adarsh.product_management.dto.response.ApiResponse;
import org.adarsh.product_management.dto.response.CategoryResponseDTO;
import org.adarsh.product_management.dto.response.ProductResponseDTO;
//import org.adarsh.product_management.repository.ProductRepository;
import org.adarsh.product_management.service.ProductService;
import org.adarsh.product_management.util.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/rajput/product")
@Validated
public class ProductController {
    @Autowired
    private ProductService productService;
    @GetMapping
    public ResponseEntity<List<ProductResponseDTO>> getAllProduct(){
        return ResponseEntity.status(HttpStatus.OK).body(productService.getAllProducts());
    }
    @PostMapping
    public ResponseEntity<ApiResponse<ProductResponseDTO>> addNewProduct(@RequestBody @Valid ProductRequestDTO dto){
        ProductResponseDTO saveProduct=productService.addNewProduct(dto);

        return new ResponseEntity<>(ResponseUtil.success("Product Added Successfully",saveProduct),HttpStatus.CREATED);
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ProductResponseDTO>> getProductById(@PathVariable Long id){
//        return ResponseEntity.status(HttpStatus.OK).body(productService.getById(id));
        ProductResponseDTO dto=productService.getById(id);
        return ResponseEntity.ok(ResponseUtil.success("Fetch Product by ID Successfully",dto));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProductById(@PathVariable Long id){
        productService.deleteById(id);
        return new ResponseEntity<>(ResponseUtil.success("Product Deleted Successfully",null),HttpStatus.OK);
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ProductResponseDTO>> updateProductById(@PathVariable Long id,@RequestBody @Valid ProductRequestDTO dto){
        ProductResponseDTO updateProduct=productService.updateById(id,dto);
        return new ResponseEntity<>(ResponseUtil.success("Product Updated Successfully",updateProduct),HttpStatus.OK);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<ApiResponse<ProductResponseDTO>> partialUpdateById(@PathVariable Long id, @RequestBody @Valid ProductPatchRequestDTO dto) {
        ProductResponseDTO updateProduct=productService.patchUpdateById(id,dto);

        return new ResponseEntity<>(ResponseUtil.success("Product Patch Updated Successfully",updateProduct),HttpStatus.OK);
    }
    @GetMapping("/page")
    public ResponseEntity<ApiResponse<Page<ProductResponseDTO>>> getAllByPage(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size
    ){
        Page<ProductResponseDTO> productList=productService.getAllProductsByPageable(page,size);
        return ResponseEntity.ok(ResponseUtil.success("Fetched Successfully By Page ",productList));
    }

}
