package org.adarsh.product_management.mapper;

import org.adarsh.product_management.dto.request.ProductRequestDTO;
import org.adarsh.product_management.dto.response.ProductResponseDTO;
import org.adarsh.product_management.entity.Category;
import org.adarsh.product_management.entity.Product;

public final class ProductMapper {
    public ProductMapper(){}
    public static Product toProduct(ProductRequestDTO dto, Category category){
//        if(dto==null){
//            throw new IllegalArgumentException("Product DTO Cannot Be empty");
//        }
//        if(category==null){
//            throw new IllegalArgumentException("Category cannot be null");
//        }

        return Product.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .price(dto.getPrice())
                .category(category)
                .build();
    }
    public static ProductResponseDTO toProductResponse(Product product){
        if(product==null){
            return null;
        }
        Long categoryId=null;
        if(product.getCategory()!=null){
            categoryId=product.getCategory().getId();
        }
        ProductResponseDTO dto=ProductResponseDTO.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .categoryId(categoryId)
                .build();
        return dto;
    }
}
