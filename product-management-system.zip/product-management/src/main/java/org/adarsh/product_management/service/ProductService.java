package org.adarsh.product_management.service;

import org.adarsh.product_management.dto.request.ProductPatchRequestDTO;
import org.adarsh.product_management.dto.request.ProductRequestDTO;
import org.adarsh.product_management.dto.response.ProductResponseDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface ProductService {
    ProductResponseDTO addNewProduct(ProductRequestDTO dto);
    List<ProductResponseDTO> getAllProducts();
    String deleteById(Long id);
    ProductResponseDTO updateById(Long id,ProductRequestDTO dto);
    ProductResponseDTO getById(Long id);
    ProductResponseDTO patchUpdateById(Long id, ProductPatchRequestDTO dto);
    Page<ProductResponseDTO> getAllProductsByPageable(int page,int size);
}
