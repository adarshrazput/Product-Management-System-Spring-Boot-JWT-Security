package org.adarsh.product_management.util;

import org.adarsh.product_management.dto.response.ApiResponse;

import java.time.LocalDateTime;

public class ResponseUtil {
    public static <T>ApiResponse<T> success(String message,T data){
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .data(data)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static <T>ApiResponse<T> failure(String message){
        return ApiResponse.<T>builder()
                .success(false)
                .message(message)
                .data(null)
                .timestamp(LocalDateTime.now())
                .build();
    }
}
