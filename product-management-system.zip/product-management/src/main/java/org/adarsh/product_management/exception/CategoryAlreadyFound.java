package org.adarsh.product_management.exception;

public class CategoryAlreadyFound extends RuntimeException{
    public CategoryAlreadyFound(String message){
        super(message);
    }
}
