package org.adarsh.product_management.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductPatchRequestDTO {
    @Size(min = 3,max = 25,message = "Product Name not less 3 characters")
    private String name;
    @Size(min = 3,max = 255,message = "Product Description Not less 3 Characters")
    private String description;
    @Positive
    private Double price;
    @Positive
    private Long categoryId;
}
