package org.adarsh.product_management.service.imp;

import lombok.RequiredArgsConstructor;
import org.adarsh.product_management.dto.request.LoginRequestDTO;
import org.adarsh.product_management.dto.request.RegisterRequestDTO;
import org.adarsh.product_management.dto.response.UserResponseDTO;
import org.adarsh.product_management.entity.User;
import org.adarsh.product_management.exception.ResourceAlreadyExists;
import org.adarsh.product_management.exception.ResourceNotFound;
import org.adarsh.product_management.mapper.UserMapper;
import org.adarsh.product_management.repository.UserRepository;
import org.adarsh.product_management.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class UserServiceImpl implements UserService {
    private final PasswordEncoder encoder;
    private final UserRepository userRepository;

    @Override
//    @Transactional(readOnly = true)
    public UserResponseDTO addNewUser(RegisterRequestDTO dto) {
//       dto.setPassword(encoder.encode(dto.getPassword()));
        Optional<User> name=userRepository.findByUsername(dto.getUsername());
        if(name.isPresent()){
            throw new ResourceAlreadyExists("User with Name : "+dto.getUsername()+" Already Exists");
        }
       User user=User.builder()
               .username(dto.getUsername())
               .password(encoder.encode(dto.getPassword()))
               .role(dto.getRole())
               .build();
        return UserMapper.userResponseDTO(userRepository.save(user));
    }

    @Override
    public UserResponseDTO login(LoginRequestDTO dto) {
       User user=userRepository.findByUsername(dto.getUsername()).orElseThrow(()->new ResourceNotFound("User Not Found"));

        if(!encoder.matches(dto.getPassword(),user.getPassword())){
            throw new RuntimeException("Password is Incorrect");
        }
        return UserResponseDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .role(user.getRole().name())
                .build();
    }
}
