package org.adarsh.product_management.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductRequestDTO {
    @NotBlank(message = "Name is required")
    @Size(min = 2,max = 25)
    private String name;
    @NotBlank(message = "Description is required")
    @Size(min = 2,max = 255,message = "Description not higher than 255 character")
    private String description;
    @Positive(message = "Price must be Positive")
    @NotNull(message = "Price is required")
    private Double price;
    @NotNull(message = "Category ID required")
    private Long categoryId;
}
