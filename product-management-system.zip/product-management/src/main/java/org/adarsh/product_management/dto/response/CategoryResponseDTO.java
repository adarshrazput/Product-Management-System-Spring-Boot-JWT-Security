package org.adarsh.product_management.dto.response;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder(value = {"category_id","category_name","productList"})
public class CategoryResponseDTO {
    private Long category_id;
    private String category_name;
    private List<ProductResponseDTO> productList;
}
