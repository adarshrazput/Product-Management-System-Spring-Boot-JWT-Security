package org.adarsh.product_management.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductResponseDTO {
    private Long id;
    private String name;
    private String description;
    private Double price;
    private Long categoryId;
    public ProductResponseDTO(){}
    public ProductResponseDTO(Long id,String name,String description,Double price,Long categoryId){
        this.id=id;
        this.name=name;
        this.description=description;
        this.price=price;
        this.categoryId=categoryId;
    }


}
