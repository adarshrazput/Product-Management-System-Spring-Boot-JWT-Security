package org.adarsh.product_management.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.adarsh.product_management.dto.request.CategoryRequestDTO;
import org.adarsh.product_management.dto.response.ApiResponse;
import org.adarsh.product_management.dto.response.CategoryResponseDTO;
import org.adarsh.product_management.service.CategoryService;
import org.adarsh.product_management.util.ResponseUtil;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rajput/category")
@RequiredArgsConstructor
@Validated
public class CategoryController {
    private final CategoryService service;

    @GetMapping
    public ResponseEntity<List<CategoryResponseDTO>> getAllCategory(){
        return new ResponseEntity<>(service.fetchAllCategories(), HttpStatus.OK);

    }
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<CategoryResponseDTO>> addCategory(@RequestBody @Valid CategoryRequestDTO dto){
        CategoryResponseDTO savedCategory=service.addCategory(dto);

        return ResponseEntity.status(HttpStatus.CREATED).body(ResponseUtil.success("New Category Added Successfully",savedCategory));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CategoryResponseDTO>> getCategoryById(@PathVariable Long id){
        CategoryResponseDTO category=service.getById(id);
        return ResponseEntity.status(HttpStatus.OK).body(ResponseUtil.success("Fetch Category by ID successfully",category));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> deleteCategoryById(@PathVariable Long id){
        service.deleteById(id);
        return ResponseEntity.status(HttpStatus.OK).body(ResponseUtil.success("Fetch Category by ID successfully",null));
    }

    @GetMapping("/page")
    public ResponseEntity<ApiResponse<Page<CategoryResponseDTO>>> getByPage(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size)
    {
        Page<CategoryResponseDTO> categoryList=service.fetchCategoryByPagination(page,size);
        return ResponseEntity.ok(ResponseUtil.success("Product By Pagination Fetched Successfully",categoryList));
    }
}
