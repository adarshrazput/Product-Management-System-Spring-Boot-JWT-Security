package org.adarsh.product_management.service;

import org.adarsh.product_management.dto.request.LoginRequestDTO;
import org.adarsh.product_management.dto.request.RegisterRequestDTO;
import org.adarsh.product_management.dto.response.UserResponseDTO;

public interface UserService {
    UserResponseDTO addNewUser(RegisterRequestDTO dto);
    UserResponseDTO login(LoginRequestDTO dto);
}
