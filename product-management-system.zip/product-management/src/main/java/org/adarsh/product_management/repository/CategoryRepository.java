package org.adarsh.product_management.repository;

import org.adarsh.product_management.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category,Long> {
    Optional<Category> findByName(String name);
    List<Category> findAllByOrderByIdAsc();

    // Using a custom @Query
    @Query("SELECT c FROM Category c ORDER BY c.id ASC")
    List<Category> findAllSortedById();

    // Using Sort parameter
//    List<Category> findAll(Sort sort);
// called as: repo.findAll(Sort.by(Sort.Direction.ASC, "id"));
}
