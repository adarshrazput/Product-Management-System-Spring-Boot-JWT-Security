package org.adarsh.product_management.service;

import org.adarsh.product_management.dto.request.CategoryRequestDTO;
import org.adarsh.product_management.dto.response.CategoryResponseDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CategoryService {
    List<CategoryResponseDTO> fetchAllCategories();
    CategoryResponseDTO addCategory(CategoryRequestDTO dto);
    String deleteById(Long id);
    CategoryResponseDTO getById(Long id);
    Page<CategoryResponseDTO> fetchCategoryByPagination(int page, int size);
}
