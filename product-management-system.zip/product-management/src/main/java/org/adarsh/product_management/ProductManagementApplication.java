package org.adarsh.product_management;

import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@OpenAPIDefinition(
       info = @Info(
               title = "Category and Product Management API",
               description = "This is Project of Product Management",
               version = "V1",
              contact = @Contact(
                      name = "Rajput",
                      email = "adarshrazput@gmail.com"
              )
        ),
        externalDocs = @ExternalDocumentation(
                url = "google.com",
                description ="External Documentation Option"
        )
)
@SpringBootApplication
public class ProductManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementApplication.class, args);
	}

}
