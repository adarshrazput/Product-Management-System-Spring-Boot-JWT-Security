package org.adarsh.product_management.service.imp;

import lombok.RequiredArgsConstructor;
import org.adarsh.product_management.dto.request.CategoryRequestDTO;
import org.adarsh.product_management.dto.response.CategoryResponseDTO;
import org.adarsh.product_management.entity.Category;
import org.adarsh.product_management.exception.ResourceAlreadyExists;
import org.adarsh.product_management.exception.ResourceNotFound;
import org.adarsh.product_management.mapper.CategoryMapper;
import org.adarsh.product_management.repository.CategoryRepository;
import org.adarsh.product_management.service.CategoryService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository repository;

    @Override
    public List<CategoryResponseDTO> fetchAllCategories() {
        return repository.findAllByOrderByIdAsc().stream().map(CategoryMapper::toResponseDTO).toList();
    }

    @Override
    public CategoryResponseDTO addCategory(CategoryRequestDTO dto) {
        Optional<Category> name=repository.findByName(dto.getName());
        if(name.isPresent()){
            throw new ResourceAlreadyExists("Category with Name : "+dto
                    .getName()+" is Already Exists");
        }
        Category category=Category.builder()
                .name(dto.getName())
                .build();
        Category savedCategory=repository.save(category);

        return CategoryMapper.toResponseDTO(savedCategory);
    }

    @Override
    public String deleteById(Long id) {
        Category category=repository.findById(id).orElseThrow(()->new ResourceNotFound("Category with Id : "+id+" Not Found!!"));
        repository.deleteById(id);
        return "Category with Id "+id+" is Deleted Successfully";
    }

    @Override
    public CategoryResponseDTO getById(Long id) {
        Category category=repository.findById(id).orElseThrow(()->new ResourceNotFound("Category with ID :" +id+" Not Found!!!"));

        return CategoryMapper.toResponseDTO(category);
    }

    @Override
//    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    @Transactional(readOnly = true)
    public Page<CategoryResponseDTO> fetchCategoryByPagination(int page, int size) {
        Pageable pageable= PageRequest.of(page,size);
      Page<Category> categoryList=repository.findAll(pageable);

        return categoryList.map(CategoryMapper::toResponseDTO);
    }
}
