package org.adarsh.product_management.entity;

public enum Role {
    ADMIN,
    SELLER
}
