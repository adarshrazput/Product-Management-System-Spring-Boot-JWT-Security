package org.adarsh.product_management.dto.response;


import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
@Data
@Builder
public class ApiResponseDTO {
    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String apiPath;
}
