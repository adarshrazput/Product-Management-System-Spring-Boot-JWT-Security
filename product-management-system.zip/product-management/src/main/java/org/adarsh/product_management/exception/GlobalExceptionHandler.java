package org.adarsh.product_management.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.adarsh.product_management.dto.response.ApiResponse;
import org.adarsh.product_management.dto.response.ApiResponseDTO;
import org.adarsh.product_management.util.ResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;

import java.nio.file.AccessDeniedException;
import java.time.LocalDateTime;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFound.class)
    public ResponseEntity<ApiResponse<Void>> handleResourceNotFound(ResourceNotFound ex){
        return new ResponseEntity<>(ResponseUtil.failure(ex.getMessage()),HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ResourceAlreadyExists.class)
    public ResponseEntity<ApiResponse<Void>> resourceAlreadyExists(ResourceAlreadyExists ex){
        return new ResponseEntity<>(ResponseUtil.failure(ex.getMessage()),HttpStatus.CONFLICT);
    }
    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ApiResponseDTO> handleBadRequest(BadRequestException ex,HttpServletRequest request){
        return buildError(ex.getMessage(),HttpStatus.BAD_REQUEST,request);
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponseDTO> handleValidation(MethodArgumentNotValidException ex,HttpServletRequest request){
        String message=ex.getFieldErrors()
                .get(0)
                .getDefaultMessage();
return buildError(message,HttpStatus.BAD_REQUEST,request);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleGeneral(Exception ex){

        return new ResponseEntity<>(ResponseUtil.failure(ex.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleAccess(AccessDeniedException ex){
        return new ResponseEntity<>(ResponseUtil.failure(ex.getMessage()),HttpStatus.FORBIDDEN);
    }
    @ExceptionHandler(HttpClientErrorException.Unauthorized.class)
    public ResponseEntity<ApiResponse<Void>> handleUnauth(HttpClientErrorException.Unauthorized ex){
        return new ResponseEntity<>(ResponseUtil.failure(ex.getMessage()),HttpStatus.UNAUTHORIZED);
    }

    public ResponseEntity<ApiResponseDTO> buildError(String message, HttpStatus status,HttpServletRequest request){
        ApiResponseDTO apiResponseDTO=ApiResponseDTO.builder()
                .timestamp(LocalDateTime.now())
                .status(status.value())
                .error(status.getReasonPhrase())
                .message(message)
                .apiPath(request.getRequestURI())
                .build();
        return new ResponseEntity<>(apiResponseDTO,status);
    }
}
