package org.adarsh.product_management.service.imp;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.adarsh.product_management.dto.request.ProductPatchRequestDTO;
import org.adarsh.product_management.dto.request.ProductRequestDTO;
import org.adarsh.product_management.dto.response.ProductResponseDTO;
import org.adarsh.product_management.entity.Category;
import org.adarsh.product_management.entity.Product;
import org.adarsh.product_management.exception.ResourceNotFound;
import org.adarsh.product_management.mapper.ProductMapper;
import org.adarsh.product_management.repository.CategoryRepository;
import org.adarsh.product_management.repository.ProductRepository;
import org.adarsh.product_management.service.ProductService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public ProductResponseDTO addNewProduct(ProductRequestDTO dto) {
//        if(dto.getCategoryId()==null){
//            throw new RuntimeException("Category Id must not be Null");
//        }
        Category category=categoryRepository.findById(dto.getCategoryId()).orElseThrow(()->new ResourceNotFound("Category with ID : "+dto.getCategoryId()+" is Not Found!"));
        Product product=ProductMapper.toProduct(dto,category);
        category.getProducts().add(product);
        Product savedProduct=productRepository.save(product);
        return ProductMapper.toProductResponse(savedProduct);
    }

    @Override
    public List<ProductResponseDTO> getAllProducts() {

        return productRepository.findAll().stream().map(ProductMapper::toProductResponse).toList();
    }

    @Override
    public String deleteById(Long id) {
        Product product=productRepository.findById(id).orElseThrow(()->new ResourceNotFound("Product with Id : "+id+" Not Found!!!"));
        productRepository.deleteById(id);
        return "Product With ID : "+id+" is Deleted Successfully";
    }

    @Override
    public ProductResponseDTO updateById(Long id, ProductRequestDTO dto) {
        Product product=productRepository.findById(id)
                .orElseThrow(()->new ResourceNotFound(
                        "Product with ID : "+id+" Not Found!!!"));
        Category category=categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(()->new ResourceNotFound(
                        "Category with ID : "+dto.getCategoryId()+" Not Found!!!"));

        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setCategory(category);
        Product updateProduct=productRepository.save(product);
        return ProductMapper.toProductResponse(updateProduct);
    }

    @Override
    public ProductResponseDTO getById(Long id) {
        Product product=productRepository.findById(id).orElseThrow(()->new ResourceNotFound("Product with ID : "+id+" Not Found!!!"));

        return ProductMapper.toProductResponse(product);
    }

    @Override
    public ProductResponseDTO patchUpdateById(Long id, ProductPatchRequestDTO dto) {
        Product product=productRepository.findById(id).orElseThrow(()->new ResourceNotFound("Product with ID : "+id+" Not Found!!!"));
//        product=Product.builder()
//                .name(dto.getName())
//                .description(dto.getDescription())
//                .price(dto.getPrice())
//                .category(category)
//                .build();
//        product=productRepository.save(product);
        if(dto.getName()!=null){
            product.setName(dto.getName());
        }
        if(dto.getDescription()!=null){
            product.setDescription(dto.getDescription());
        }
        if(dto.getPrice()!=null){
            product.setPrice(dto.getPrice());
        }
        if(dto.getCategoryId()!=null){
        Category category=categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(()->
                        new ResourceNotFound("" +
                                "Category with ID : "+dto.getCategoryId()+" Not Found!!!"));
            product.setCategory(category);
        }
        Product savedProduct=productRepository.save(product);
        return ProductMapper.toProductResponse(savedProduct);
    }

    @Override
    public Page<ProductResponseDTO> getAllProductsByPageable(int page, int size) {
        Pageable pageable= PageRequest.of(page,size);

        return productRepository.findAll(pageable).map(ProductMapper::toProductResponse);
    }
}
