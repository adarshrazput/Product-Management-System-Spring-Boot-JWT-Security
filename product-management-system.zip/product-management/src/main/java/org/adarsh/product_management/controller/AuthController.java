package org.adarsh.product_management.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.adarsh.product_management.dto.request.LoginRequestDTO;
import org.adarsh.product_management.dto.request.RegisterRequestDTO;
import org.adarsh.product_management.dto.response.ApiResponse;
import org.adarsh.product_management.dto.response.UserResponseDTO;
import org.adarsh.product_management.service.UserService;
import org.adarsh.product_management.util.ResponseUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Validated
public class AuthController {
    private final UserService userService;

    @PostMapping("/register")
    public ApiResponse<UserResponseDTO> register(@RequestBody @Valid RegisterRequestDTO dto) {
        UserResponseDTO saveUser=userService.addNewUser(dto);
        return ResponseUtil.success("Register new User Successfully",saveUser);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<UserResponseDTO>> login(@RequestBody @Valid LoginRequestDTO dto) {
        UserResponseDTO loginuser = userService.login(dto);
        return new ResponseEntity<>(ResponseUtil.success("Login Successfully", loginuser), HttpStatus.OK);
    }
}
