package org.adarsh.product_management.mapper;

import org.adarsh.product_management.dto.request.CategoryRequestDTO;
import org.adarsh.product_management.dto.response.CategoryResponseDTO;
import org.adarsh.product_management.dto.response.ProductResponseDTO;
import org.adarsh.product_management.entity.Category;

import java.util.List;

public final class CategoryMapper {
    public CategoryMapper(){}
    public static Category toCategory(CategoryRequestDTO dto){
        if(dto==null){
            return null;
        }
        return Category.builder()
                .name(dto.getName())
                .build();
    }


    public static CategoryResponseDTO toResponseDTO(Category category){

        if(category == null){
            return null;
        }

        List<ProductResponseDTO> productList = category.getProducts() == null
                ? List.of()
                : category.getProducts()
                .stream()
                .map(ProductMapper::toProductResponse)
                .toList();

       CategoryResponseDTO categoryDto=CategoryResponseDTO.builder()
                .category_id(category.getId())
                .category_name(category.getName())
                .productList(productList)
                .build();
//       CategoryResponseDTO categoryDto=new CategoryResponseDTO();
//       categoryDto.setCategory_id(category.getId());
//       categoryDto.setCategory_name(category.getName());
//       categoryDto.setProductList(productList);
       return categoryDto;
    }
}
