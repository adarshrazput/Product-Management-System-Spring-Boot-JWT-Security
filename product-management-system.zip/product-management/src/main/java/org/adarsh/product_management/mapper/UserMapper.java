package org.adarsh.product_management.mapper;

import org.adarsh.product_management.dto.response.UserResponseDTO;
import org.adarsh.product_management.entity.User;

public final class UserMapper {
    public UserMapper(){}
    public static UserResponseDTO userResponseDTO(User user){
        if(user==null){
            return null;
        }
        return UserResponseDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .role(user.getRole().name())
                .build();
    }
}
